Volume 2: Preparing for the Cloud
