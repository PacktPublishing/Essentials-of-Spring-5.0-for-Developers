@RestController
class RestApp {
	@RequestMapping("/")
	String index() {
		"Success!"
	}
}
