package wkennedy.github.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Section11Application {

	public static void main(String[] args) {
		SpringApplication.run(Section11Application.class, args);
	}
}
