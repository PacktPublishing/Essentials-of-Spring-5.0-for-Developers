package com.github.wkennedy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Section31Application {

	public static void main(String[] args) {
		SpringApplication.run(Section31Application.class, args);
	}
}
