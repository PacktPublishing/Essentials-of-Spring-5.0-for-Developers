# Api Documentation

## Overview
Api Documentation

### Version information
Version: 1.0

### Contact information

### License information
License: Apache 2.0
License URL: http://www.apache.org/licenses/LICENSE-2.0

Terms of service: urn:tos

### URI scheme
Host: localhost
BasePath: /

### Tags

* Simple Service: A basic API example
* simple-controller: Simple Controller


