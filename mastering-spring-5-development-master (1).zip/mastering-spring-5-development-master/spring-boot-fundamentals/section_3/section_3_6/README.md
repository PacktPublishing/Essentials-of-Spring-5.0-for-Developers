First run:

    docker-compose up
    
in the docker directory.  This will spin up an image that has thrift installed that will generate classes
from the thrift file in src/main/thrift.  You can then do a Maven build.